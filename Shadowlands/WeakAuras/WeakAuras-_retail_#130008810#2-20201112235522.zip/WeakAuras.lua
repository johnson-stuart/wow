
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["displays"] = {
	},
	["lastArchiveClear"] = 1605225131,
	["minimap"] = {
		["hide"] = false,
	},
	["lastUpgrade"] = 1605225138,
	["dbVersion"] = 39,
	["registered"] = {
	},
	["login_squelch_time"] = 10,
}
